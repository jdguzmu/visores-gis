define({
  "_widgetLabel": "Pievienot datus",
  "noOptionsConfigured": "Netika konfigurēta neviena opcija.",
  "tabs": {
    "search": "Meklēt",
    "url": "URL",
    "file": "Fails"
  },
  "search": {
    "featureLayerTitlePattern": "{serviceName}–{layerName}",
    "layerInaccessible": "Slānim nevar piekļūt.",
    "loadError": "AddData, nevarēja ielādēt:",
    "searchBox": {
      "search": "Meklēt",
      "placeholder": "Meklēšana..."
    },
    "bboxOption": {
      "bbox": "Kartē"
    },
    "scopeOptions": {
      "anonymousContent": "Saturs",
      "myContent": "Mans Saturs",
      "myOrganization": "Mana organizācija",
      "curated": "Pārraudzīts",
      "ArcGISOnline": "ArcGIS Online"
    },
    "sortOptions": {
      "prompt": "Atlasīt pēc:",
      "relevance": "Svarīgums",
      "title": "Virsraksts",
      "owner": "Īpašnieks",
      "rating": "Vērtējums",
      "views": "Skatījumi",
      "date": "Datums",
      "switchOrder": "Slēdzis"
    },
    "typeOptions": {
      "prompt": "Tips",
      "mapService": "Kartes serviss",
      "featureService": "Elementu pakalpojums",
      "imageService": "Attēlu pakalpojums",
      "vectorTileService": "Vektoru mozaīkas pakalpojums",
      "kml": "KML",
      "wms": "WMS"
    },
    "resultsPane": {
      "noMatch": "Netika atrasts neviens rezultāts."
    },
    "paging": {
      "first": "<<",
      "firstTip": "Pirmais",
      "previous": "<",
      "previousTip": "Iepriekšējais",
      "next": ">",
      "nextTip": "Tālāk",
      "pagePattern": "{page}"
    },
    "resultCount": {
      "countPattern": "{count} {type}",
      "itemSingular": "Vienība",
      "itemPlural": "Vienības"
    },
    "item": {
      "actions": {
        "add": "Pievienot",
        "close": "Aizvērt",
        "remove": "Izņemt",
        "details": "Detaļas",
        "done": "Pabeigts",
        "editName": "Rediģēt nosaukumu"
      },
      "messages": {
        "adding": "Tiek pievienots...",
        "removing": "Tiek noņemts...",
        "added": "Pievienots",
        "addFailed": "Pievienošana neizdevās",
        "unsupported": "Neatbalstīts"
      },
      "typeByOwnerPattern": "{type}, īpašnieks {owner}",
      "dateFormat": "dd.MM.yyyy",
      "datePattern": "{date}",
      "ratingsCommentsViewsPattern": "{ratings} {ratingsIcon} {comments} {commentsIcon} {views} {viewsIcon}",
      "ratingsCommentsViewsLabels": {
        "ratings": "vērtējumi\", \"komentāri\": \"komentāri\", \"skati\": \"skati"
      },
      "types": {
        "Map Service": "Kartes serviss",
        "Feature Service": "Elementu serviss",
        "Image Service": "Attēlu serviss",
        "Vector Tile Service": "Vektoru mozaīkas serviss",
        "WMS": "WMS",
        "KML": "KML"
      }
    }
  },
  "addFromUrl": {
    "type": "Veids",
    "url": "URL",
    "types": {
      "ArcGIS": "ArcGIS Server web serviss",
      "WMS": "WMS OGC web serviss",
      "WMTS": "WMTS OGC web serviss",
      "WFS": "WFS OGC web serviss",
      "KML": "KML fails",
      "GeoRSS": "GeoRSS fails",
      "CSV": "CSV fails"
    },
    "samplesHint": "Parauga URL",
    "invalidURL": "Lūdzu, ievadiet URL, kas sākas ar http:// vai https://. "
  },
  "addFromFile": {
    "intro": "Jūs varat nomest vai norādīt kādu no tālāk aprakstītajiem failu tipiem.",
    "types": {
      "Shapefile": "Shape fails (.zip paplašinājums; ZIP arhīvs, kurā ietilpst visi Shape faila faili)",
      "CSV": "CSV fails (.csv paplašinājums; ar adresi vai ģeogrāfisko platumu un ģeogrāfisko garumu; vērtības atdalītas ar komatu, semikolu vai tabulatoru)",
      "KML": "KML fails (.kml)",
      "GPX": "GPX fails (.gpx paplašinājums, GPS Exchange formāts)",
      "GeoJSON": "GeoJSON fails (.geo.json vai .geojson paplašinājums)"
    },
    "generalizeOn": "Ģeneralizēt elementus priekš parādīšanas web",
    "dropOrBrowse": "Nomest vai pārlūkot",
    "browse": "Pārlūkot",
    "invalidType": "Šis faila tips netiek atbalstīts.",
    "addingPattern": "{filename}: notiek pievienošana...",
    "addFailedPattern": "{filename}: neizdevās pievienot",
    "featureCountPattern": "{filename}: {count} elements(i)",
    "invalidTypePattern": "{filename}: šis tips netiek atbalstīts",
    "maxFeaturesAllowedPattern": "Maksimālais atļautais elementu skaits: {count}",
    "layerNamePattern": "{filename} — {name}",
    "generalIssue": "Radās kāda problēma.",
    "kmlProjectionMismatch": "Kartes telpiskā atskaite un KML slānis nesakrīt, un klientam nav iespējams veikt konvertāciju.",
    "featureLocationsCouldNotBeFound": "Nevarēja atrast elementus: nezināmi vai nederīgi atrašanās vietas lauki. Fails tiks pievienots kā tabula."
  },
  "layerList": {
    "caption": "Slāņi",
    "noLayersAdded": "Nav pievienots neviens slānis.",
    "removeLayer": "Noņemt slāni",
    "back": "Atpakaļ"
  }
});